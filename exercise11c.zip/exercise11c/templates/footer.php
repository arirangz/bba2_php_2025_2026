<footer>Copyright</footer>

</body>

</html>